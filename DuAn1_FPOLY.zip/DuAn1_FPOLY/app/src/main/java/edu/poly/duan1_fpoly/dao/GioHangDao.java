package edu.poly.duan1_fpoly.dao;

import java.util.ArrayList;

import edu.poly.duan1_fpoly.fragment.LaptopFragment;
import edu.poly.duan1_fpoly.fragment.PhoneFragment;
import edu.poly.duan1_fpoly.models.GioHang;

public class GioHangDao {
    public static ArrayList<GioHang> listGioHang = new ArrayList<>();
    public static ArrayList<GioHang> listMuaHang = new ArrayList<>();
}
