package edu.poly.duan1_fpoly.utils;

public class Server {
    public static final String LinkInsertUser = "https://nguyenchithuan123.000webhostapp.com/insertuser.php";
    public static final String LinkAllUser = "https://nguyenchithuan123.000webhostapp.com/getalluser.php";
    public static final String LinkUpdateUser = "https://nguyenchithuan123.000webhostapp.com/updateuser.php";
    public static final String LinkSanPham = "https://nguyenchithuan123.000webhostapp.com/getsanpham.php";
    public static final String LinkSanPhamTheLoai = "https://nguyenchithuan123.000webhostapp.com/getsanphamtheoloai.php";
    public static final String LinkSanPhamMoiNhat = "https://nguyenchithuan123.000webhostapp.com/getsanphammoinhat.php";
    public static final String LinkSanPhamMoiNhatTheoLoai = "https://nguyenchithuan123.000webhostapp.com/getsanphammoinhattheoloai.php";
    public static final String LinkSearch = "https://nguyenchithuan123.000webhostapp.com/getsearchnamesp.php";
    public static final String LinkSapXep = "https://nguyenchithuan123.000webhostapp.com/getsapxepsp.php";
    public static final String LinkInsertDonHang = "https://nguyenchithuan123.000webhostapp.com/insertdonhang.php";
    public static final String LinkInsertChiTietDonHang = "https://nguyenchithuan123.000webhostapp.com/insertchitietdonhang.php";
    public static final String LinkXemDonHang = "https://nguyenchithuan123.000webhostapp.com/xemdonhang.php";
    public static final String LinkThongKe = "https://nguyenchithuan123.000webhostapp.com/thongke.php";
}
