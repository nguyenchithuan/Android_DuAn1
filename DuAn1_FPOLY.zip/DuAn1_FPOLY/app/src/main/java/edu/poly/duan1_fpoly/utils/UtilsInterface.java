package edu.poly.duan1_fpoly.utils;

public interface UtilsInterface {
    void setTongGia(); // set lại tổng giá của giỏ hàng
}
